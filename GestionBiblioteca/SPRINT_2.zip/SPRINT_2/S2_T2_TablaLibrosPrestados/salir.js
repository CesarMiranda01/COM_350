// Obtener el botón estático de salir
var boton = document.getElementById("boton-salir");

// Agregarle un evento de clic al botón
boton.addEventListener("click", function() {
    // Redirigir al usuario a otra página web
    window.location.href = "https://www.google.com";
});
