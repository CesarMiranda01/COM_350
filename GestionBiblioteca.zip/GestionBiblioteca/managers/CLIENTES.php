<?php
        header('location: ../clients/index.html');
        
?>